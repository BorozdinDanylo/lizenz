package com.example.demo.Controller;

// import ch.qos.logback.core.model.Model;
import org.springframework.ui.Model;
import com.example.demo.Entity.Customer;
import com.example.demo.Service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CustomerController {
    @Autowired
    CustomerService customerService;

    @RequestMapping("/customer/save")
    public String saveCustomer(@ModelAttribute Customer customer) {
        customerService.saveCustomer(customer);

        return "redirect:/kunde/table";
    }

    @RequestMapping("/kunde/table/change")
    public String changeCustomer(@RequestParam("changeId") String id, Model model) {
        model.addAttribute(customerService.getCustomerById(Long.parseLong(id)));

        return "work/version/Kunde.html";
    }

    @RequestMapping("/kunde/table/delete")
    public String deleteCustomer(@RequestParam("deleteId") String id, Model model) {
        customerService.delete(Long.parseLong(id));

        return "redirect:/kunde/table";
    }
}
