package com.example.demo.viewController;

// import ch.qos.logback.core.model.Model;
import com.example.demo.Entity.Customer;
import com.example.demo.Service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class CustomerViewController {
    @Autowired
    private CustomerService customerService;

    @RequestMapping("/kunde")
    public String getCustomers(Model model) {
        Customer customer = new Customer();
        model.addAttribute("customer", customer);
        return "work/version/Kunde.html";
    }

    @RequestMapping("/kunde/table")
    public String getTable(Model model) {
        model.addAttribute("customers", customerService.getAllCustomers());

        return "work/version/KundenTabele.html";
    }
}
